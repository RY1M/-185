﻿using System;

namespace ToursApp1
{
    internal class ToursBaseEntities
    {
        internal static object GetContext()
        {
            throw new NotImplementedException();
        }
    }
}