﻿namespace AutoService1
{
    public class ContentPage
    {
    }
}