﻿using System;

namespace AutoService1
{
    internal class XamlCompilationAttribute : Attribute
    {
    }
}